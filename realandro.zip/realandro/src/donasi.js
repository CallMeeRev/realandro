const donasi = () => {
	return `❀𝗔𝗥𝟭𝟱𝗕𝗢𝗧❀	

  Hi👋️
  
          *DONATE*
          
┏━━━°❀ ❬*DONASINYA GAN*❭ ❀°━━━┓
┃
┏❉ *#info*
┣❉ *#Donasi* 
┗❉ *#creator* 
┃
┣━━━°❀ ❬ 𝗗𝗢𝗡𝗔𝗦𝗜 ❭ ❀°━━━⊱
┃
┣➥ *PULSA:* 0831-6444-5159
┃
┣━━━━━━━━━━━━━━━━━━━━
┃
┃*I AM R E V O L T*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ 𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬 𝗔𝗥𝗜𝗦𝟭𝟴𝟳 𝗜𝗗
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
